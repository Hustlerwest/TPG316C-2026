class Profile {
  String imagePath;
  String name;
  String surname;
  String cellphone;
  String email;
  String role;
  String programmingLanguage;

  Profile({
    required this.imagePath,
    required this.name,
    required this.surname,
    required this.cellphone,
    required this.email,
    required this.role,
    required this.programmingLanguage,
  });
}
