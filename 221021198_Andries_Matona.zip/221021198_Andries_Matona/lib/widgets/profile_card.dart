import 'package:flutter/material.dart';

class ProfileCard extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final IconData? icon;
  final EdgeInsetsGeometry? padding;

  const ProfileCard({
    super.key,
    required this.title,
    required this.children,
    this.icon,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: padding ?? const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Card Header
            if (title.isNotEmpty) ...[
              Row(
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: Colors.blue, size: 20),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Divider(height: 1),
              const SizedBox(height: 16),
            ],

            // Card Content
            ...children,
          ],
        ),
      ),
    );
  }
}
