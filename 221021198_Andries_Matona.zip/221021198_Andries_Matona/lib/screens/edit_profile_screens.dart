import 'package:flutter/material.dart';
import '../models/profile.dart';

class EditProfileScreen extends StatefulWidget {
  final Profile profile;

  const EditProfileScreen({super.key, required this.profile});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController nameController;
  late TextEditingController surnameController;
  late TextEditingController cellphoneController;
  late TextEditingController emailController;
  late TextEditingController roleController;
  late TextEditingController languageController;

  late String imageUrl;
  final _formKey = GlobalKey<FormState>(); // Add form key for validation

  @override
  void initState() {
    super.initState();
    // Initialize controllers with existing profile data
    nameController = TextEditingController(text: widget.profile.name);
    surnameController = TextEditingController(text: widget.profile.surname);
    cellphoneController = TextEditingController(text: widget.profile.cellphone);
    emailController = TextEditingController(text: widget.profile.email);
    roleController = TextEditingController(text: widget.profile.role);
    languageController =
        TextEditingController(text: widget.profile.programmingLanguage);
    imageUrl = widget.profile.imagePath;
  }

  @override
  void dispose() {
    // Dispose controllers to prevent memory leaks
    nameController.dispose();
    surnameController.dispose();
    cellphoneController.dispose();
    emailController.dispose();
    roleController.dispose();
    languageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          TextButton(
            onPressed: _saveProfile,
            child: const Text(
              'Save',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Editable Profile Image
              Center(
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 70,
                      backgroundImage: NetworkImage(imageUrl),
                      backgroundColor: Colors.grey[200],
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon:
                              const Icon(Icons.camera_alt, color: Colors.white),
                          onPressed: _pickImage,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Edit Form Fields
              Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      _buildTextField('Name', nameController, Icons.person),
                      const SizedBox(height: 16),
                      _buildTextField(
                          'Surname', surnameController, Icons.person_outline),
                      const SizedBox(height: 16),
                      _buildTextField(
                          'Cellphone', cellphoneController, Icons.phone,
                          keyboardType: TextInputType.phone),
                      const SizedBox(height: 16),
                      _buildTextField('Email', emailController, Icons.email,
                          keyboardType: TextInputType.emailAddress),
                      const SizedBox(height: 16),
                      _buildTextField('Role', roleController, Icons.work),
                      const SizedBox(height: 16),
                      _buildTextField('Programming Language',
                          languageController, Icons.code),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // Cancel button
              OutlinedButton(
                onPressed: () {
                  Navigator.pop(context); // Go back without saving
                },
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  side: const BorderSide(color: Colors.grey),
                ),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      String label, TextEditingController controller, IconData icon,
      {TextInputType? keyboardType}) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $label';
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.blue),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.blue, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.red),
        ),
      ),
    );
  }

  void _pickImage() {
    // For this project without database, we'll just use a placeholder
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Change Profile Image'),
        content: const Text(
            'In a production app, you would select an image from gallery here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );

    // For demo purposes, we'll use a different placeholder
    setState(() {
      imageUrl = 'https://via.placeholder.com/150/0000ff/ffffff?text=New+Image';
    });
  }

  void _saveProfile() {
    // Validate form
    if (_formKey.currentState!.validate()) {
      // Create updated profile
      final updatedProfile = Profile(
        imagePath: imageUrl,
        name: nameController.text,
        surname: surnameController.text,
        cellphone: cellphoneController.text,
        email: emailController.text,
        role: roleController.text,
        programmingLanguage: languageController.text,
      );

      // Print for debugging
      print("Saving profile: ${updatedProfile.name}");

      // Return updated profile to previous screen
      Navigator.pop(context, updatedProfile);
    }
  }
}
