import 'package:flutter/material.dart';

class ProfileImage extends StatelessWidget {
  final String imageUrl;
  final double radius;
  final bool isEditable;
  final VoidCallback? onEditPressed;

  const ProfileImage({
    super.key,
    required this.imageUrl,
    this.radius = 80,
    this.isEditable = false,
    this.onEditPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: [
          // Profile Avatar
          CircleAvatar(
            radius: radius,
            backgroundImage: imageUrl.startsWith('http')
                ? NetworkImage(imageUrl) as ImageProvider
                : AssetImage(imageUrl) as ImageProvider,
            child: imageUrl.isEmpty ? Icon(Icons.person, size: radius) : null,
          ),

          // Edit Button (only shown if isEditable is true)
          if (isEditable)
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: const Icon(Icons.camera_alt, color: Colors.white),
                  onPressed: onEditPressed,
                  iconSize: radius * 0.3,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
