import 'package:flutter/material.dart';
import '../models/profile.dart';
import 'edit_profile_screens.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late Profile profile;
  bool isEditing = false; // Track if we're in editing mode

  @override
  void initState() {
    super.initState();
    profile = Profile(
      imagePath: 'https://via.placeholder.com/150',
      name: 'Andries Mohau',
      surname: 'Matona',
      cellphone: '+27 63 589 3570',
      email: '221021198@stud.cut.ac.za',
      role: 'Flutter Developer',
      programmingLanguage: 'Dart',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        elevation: 0,
        // Center title with buttons
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Edit Button
            Container(
              margin: const EdgeInsets.only(right: 10),
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    isEditing = true; // Enter editing mode
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.blue,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.edit, size: 18),
                    SizedBox(width: 5),
                    Text('Edit'),
                  ],
                ),
              ),
            ),

            // Save Button (only visible in editing mode)
            if (isEditing)
              Container(
                margin: const EdgeInsets.only(left: 10),
                child: ElevatedButton(
                  onPressed: () async {
                    // Navigate to edit screen and wait for result
                    final updatedProfile = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            EditProfileScreen(profile: profile),
                      ),
                    );

                    if (updatedProfile != null) {
                      setState(() {
                        profile = updatedProfile;
                        isEditing = false; // Exit editing mode
                      });
                    } else {
                      setState(() {
                        isEditing =
                            false; // Exit editing mode even if cancelled
                      });
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 10,
                    ),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.save, size: 18),
                      SizedBox(width: 5),
                      Text('Save'),
                    ],
                  ),
                ),
              ),
          ],
        ),

        // Remove the default actions and back button
        automaticallyImplyLeading: false,

        // You can also add a settings icon on the right if needed
        actions: [
          if (!isEditing)
            IconButton(
              icon: const Icon(Icons.settings, color: Colors.white),
              onPressed: () {
                // Optional settings
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Settings pressed')),
                );
              },
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Profile Image
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 80,
                    backgroundImage: NetworkImage(profile.imagePath),
                    backgroundColor: Colors.grey[200],
                  ),
                  // Show camera icon when in editing mode
                  if (isEditing)
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: const Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                          ),
                          onPressed: () {
                            // Simulate image change
                            setState(() {
                              profile.imagePath =
                                  'https://via.placeholder.com/150/0000ff/ffffff?text=New+Image';
                            });
                          },
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Profile Information Card
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    _buildInfoField(
                      icon: Icons.person,
                      label: 'Name',
                      value: profile.name,
                      isEditing: isEditing,
                      onChanged: (value) =>
                          setState(() => profile.name = value),
                    ),
                    const Divider(),
                    _buildInfoField(
                      icon: Icons.person_outline,
                      label: 'Surname',
                      value: profile.surname,
                      isEditing: isEditing,
                      onChanged: (value) =>
                          setState(() => profile.surname = value),
                    ),
                    const Divider(),
                    _buildInfoField(
                      icon: Icons.phone,
                      label: 'Cellphone',
                      value: profile.cellphone,
                      isEditing: isEditing,
                      onChanged: (value) =>
                          setState(() => profile.cellphone = value),
                      keyboardType: TextInputType.phone,
                    ),
                    const Divider(),
                    _buildInfoField(
                      icon: Icons.email,
                      label: 'Email',
                      value: profile.email,
                      isEditing: isEditing,
                      onChanged: (value) =>
                          setState(() => profile.email = value),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const Divider(),
                    _buildInfoField(
                      icon: Icons.work,
                      label: 'Role',
                      value: profile.role,
                      isEditing: isEditing,
                      onChanged: (value) =>
                          setState(() => profile.role = value),
                    ),
                    const Divider(),
                    _buildInfoField(
                      icon: Icons.code,
                      label: 'Programming Language',
                      value: profile.programmingLanguage,
                      isEditing: isEditing,
                      onChanged: (value) =>
                          setState(() => profile.programmingLanguage = value),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Cancel button (visible only in editing mode)
            if (isEditing)
              OutlinedButton(
                onPressed: () {
                  setState(() {
                    isEditing = false; // Exit editing mode without saving
                  });
                },
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  side: const BorderSide(color: Colors.red),
                  foregroundColor: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text('Cancel Editing'),
              ),
          ],
        ),
      ),
    );
  }

  // Helper method to build editable or read-only fields
  Widget _buildInfoField({
    required IconData icon,
    required String label,
    required String value,
    required bool isEditing,
    required Function(String) onChanged,
    TextInputType? keyboardType,
  }) {
    if (isEditing) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4.0),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: Colors.blue, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextFormField(
                initialValue: value,
                keyboardType: keyboardType,
                decoration: InputDecoration(
                  labelText: label,
                  labelStyle: const TextStyle(fontSize: 14),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 8),
                ),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
                onChanged: onChanged,
              ),
            ),
          ],
        ),
      );
    } else {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: Colors.blue, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
  }
}
